// Gestione del Carrello
let cart = [];

// Carica il carrello dal localStorage
document.addEventListener('DOMContentLoaded', () => {
    const storedCart = localStorage.getItem('cart');
    if (storedCart) {
        cart = JSON.parse(storedCart);
    }
    displayCart();
    setupProductDetailModal();
    setupContactModal();
    setupHomepageProductImages(); // Aggiunto per assegnare event listener alle immagini nella Home
});

// Aggiungi al Carrello
const addToCartButtons = document.querySelectorAll('.add-to-cart');
addToCartButtons.forEach(button => {
    button.addEventListener('click', () => {
        const name = button.getAttribute('data-name');
        const price = parseFloat(button.getAttribute('data-price'));
        const image = button.getAttribute('data-image');
        cart.push({ name, price, image });
        localStorage.setItem('cart', JSON.stringify(cart));
        alert(`${name} è stato aggiunto al carrello.`);
    });
});

// Visualizza il Carrello nella pagina cart.html
function displayCart() {
    if (window.location.pathname.includes('cart.html')) {
        const cartItemsDiv = document.getElementById('cart-items');
        const totalEl = document.getElementById('total');
        if (cart.length === 0) {
            cartItemsDiv.innerHTML = '<p>Il tuo carrello è vuoto.</p>';
            totalEl.textContent = 'Totale: €0.00';
            return;
        }
        cartItemsDiv.innerHTML = '';
        let total = 0;
        cart.forEach((item, index) => {
            total += item.price;
            const itemDiv = document.createElement('div');
            itemDiv.className = 'cart-item';

            // Creazione dell'immagine del prodotto
            const img = document.createElement('img');
            img.src = item.image;
            img.alt = item.name;
            img.className = 'cart-product-image'; // Per identificare l'immagine nel carrello
            img.setAttribute('data-name', item.name);
            img.setAttribute('data-price', item.price);
            img.setAttribute('data-image', item.image);
            img.setAttribute('data-description', getProductDescription(item.name)); // Funzione per ottenere la descrizione

            // Creazione dei dettagli del prodotto
            const detailsDiv = document.createElement('div');
            detailsDiv.className = 'product-details';
            const nameSpan = document.createElement('span');
            nameSpan.textContent = item.name;
            const priceSpan = document.createElement('span');
            priceSpan.textContent = `€${item.price.toFixed(2)}`;
            detailsDiv.appendChild(nameSpan);
            detailsDiv.appendChild(priceSpan);

            // Creazione del pulsante di rimozione
            const removeSpan = document.createElement('span');
            removeSpan.className = 'remove-item';
            removeSpan.textContent = '×';
            removeSpan.setAttribute('data-index', index);

            // Aggiunta di tutti gli elementi al cart-item
            itemDiv.appendChild(img);
            itemDiv.appendChild(detailsDiv);
            itemDiv.appendChild(removeSpan);

            cartItemsDiv.appendChild(itemDiv);
        });
        totalEl.textContent = `Totale: €${total.toFixed(2)}`;

        // Aggiungi event listener per i pulsanti di rimozione
        const removeButtons = document.querySelectorAll('.remove-item');
        removeButtons.forEach(button => {
            button.addEventListener('click', () => {
                const index = button.getAttribute('data-index');
                removeItem(index);
            });
        });

        // Aggiungi event listener per le immagini dei prodotti nel carrello
        const cartProductImages = document.querySelectorAll('.cart-product-image');
        cartProductImages.forEach(img => {
            img.addEventListener('click', () => {
                const name = img.getAttribute('data-name');
                const price = parseFloat(img.getAttribute('data-price'));
                const image = img.getAttribute('data-image');
                const description = img.getAttribute('data-description');
                openProductDetailsModal(name, price, image, description);
            });
        });
    }
}

// Funzione per rimuovere un elemento dal carrello
function removeItem(index) {
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    displayCart();
}

// Funzione per ottenere la descrizione del prodotto in base al nome
function getProductDescription(name) {
    const productDescriptions = {
        "Laptop Asus Gaming": "Un potente laptop Asus ideale per il gaming con processore Intel i7 e scheda grafica RTX 3060.",
        "Monitor Gaming": "Monitor gaming da 27 pollici con risoluzione 144Hz e tecnologia IPS per colori vividi.",
        "Samsung S24": "Samsung S24 con display QLED e tecnologia HDR per un'esperienza visiva eccezionale.",
        "Laptop MSI": "Laptop MSI con processore AMD Ryzen 7 e scheda grafica NVIDIA GTX 1660 Ti, perfetto per professionisti e gamer.",
        "iPhone 16": "iPhone 16 con fotocamera avanzata e processore A16 Bionic per prestazioni senza pari.",
        "iPad 10'Gen": "iPad di 10a generazione con display Retina e supporto Apple Pencil per creatività senza limiti.",
        "Mac Air M2": "Mac Air M2 con chip Apple M2 per prestazioni eccezionali e efficienza energetica.",
        "AirTag 4 Pack": "Set di 4 AirTag per tracciare i tuoi oggetti personali con facilità tramite l'app Find My.",
        "PC Fisso SUPER POTENTE": "PC Fisso SUPER POTENTE con componenti di ultima generazione per gaming e lavori professionali.",
        "Tastiera Meccanica": "Tastiera meccanica con switch Cherry MX per una digitazione precisa e reattiva.",
        "Mouse Gaming": "Mouse gaming con DPI regolabili e design ergonomico per lunghe sessioni di gioco.",
        "Cuffie Gaming": "Cuffie gaming con audio surround e microfono a cancellazione del rumore per un'esperienza immersiva."
    };
    return productDescriptions[name] || "Descrizione non disponibile.";
}

// Funzione per aprire il modal dei dettagli del prodotto
function openProductDetailsModal(name, price, image, description) {
    const modal = document.getElementById('product-details');
    const productName = document.getElementById('product-name');
    const productImage = document.getElementById('product-image');
    const productDescription = document.getElementById('product-description');
    const productPrice = document.getElementById('product-price');

    productName.textContent = name;
    productImage.src = image;
    productImage.alt = name;
    productDescription.textContent = description;
    productPrice.textContent = `Prezzo: €${price.toFixed(2)}`;

    modal.style.display = 'block';
}

// Configura il modal dei dettagli del prodotto
function setupProductDetailModal() {
    const modal = document.getElementById('product-details');
    const closeBtn = modal.querySelector('.close');

    // Chiudi il modal quando si clicca sulla X
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    // Chiudi il modal quando si clicca fuori dal contenuto
    window.addEventListener('click', (event) => {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    });
}

// Configura il modal dei Contatti
function setupContactModal() {
    const contattiBtn = document.getElementById('contatti-btn');
    const contattiModal = document.getElementById('contatti');
    const closeContattiBtn = contattiModal.querySelector('.close');

    if (contattiBtn) {
        contattiBtn.addEventListener('click', (e) => {
            e.preventDefault();
            contattiModal.style.display = 'block';
        });
    }

    if (closeContattiBtn) {
        closeContattiBtn.addEventListener('click', () => {
            contattiModal.style.display = 'none';
        });
    }

    // Chiudi il modal cliccando fuori
    window.addEventListener('click', (event) => {
        if (event.target == contattiModal) {
            contattiModal.style.display = 'none';
        }
    });
}

// Funzione per assegnare event listener alle immagini dei prodotti nella Home
function setupHomepageProductImages() {
    const productImages = document.querySelectorAll('.product-image');
    productImages.forEach(img => {
        img.addEventListener('click', () => {
            const name = img.getAttribute('data-name');
            const price = parseFloat(img.getAttribute('data-price'));
            const image = img.getAttribute('data-image');
            const description = img.getAttribute('data-description');
            openProductDetailsModal(name, price, image, description);
        });
    });
}

// Gestione del Checkout
const checkoutButton = document.getElementById('checkout');
if (checkoutButton) {
    checkoutButton.addEventListener('click', () => {
        if (cart.length === 0) {
            alert('Il tuo carrello è vuoto.');
            return;
        }
        // Mostra l'alert
        alert('Ordine Completato, Grazie :)');
        // Svuota il carrello
        cart = [];
        localStorage.setItem('cart', JSON.stringify(cart));
        // Reindirizza alla pagina principale
        window.location.href = 'index.html';
    });
}
